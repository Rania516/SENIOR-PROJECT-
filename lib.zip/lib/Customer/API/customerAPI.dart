// ignore_for_file: camel_case_types, non_constant_identifier_names, avoid_print

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:logistic_cravan/consts.dart';

class authentication {
  authentication();

  // function to sign up a new user in applecation
  Future<bool> sign_Up(String email, String name, String password,
      String address, String phoneNumeber) async {
    var url = Uri.parse('$domainName/api/customers/register');

    Map<String, String> headers = {
      'Content-Type': 'application/json',
    };

    Map<String, dynamic> body = {
      // 'userName': userName,
      'name': name,
      'email': email,
      'phoneNumebr': phoneNumeber,
      'address': address,
      'password': password,
    };
    print("body : $body");
    try {
      var response = await http.post(
        url,
        headers: headers,
        body: jsonEncode(body),
      );
      print(response.body);
      if (response.statusCode == 200) {
        print('Sign up request successful');
        print('Response: ${response.body}');
        var jsonResponce = jsonDecode(response.body);
        if (jsonResponce == true) {
          return true;
        } else {
          return false;
        }
      } else {
        print(
            'Failed to make Sign up request. Status code: ${response.statusCode}');
        return false;
      }
    } catch (e) {
      print('Error making Sign up request: $e');
      return false;
    }
  }

  Future<bool> login(String usernameOrEmail, String password) async {
    var url = Uri.parse('$domainName/api/customers/logIn');

    Map<String, String> headers = {
      'Content-Type': 'application/json',
    };

    Map<String, dynamic> body = {
      // 'userName': userName,
      'usernameOrEmail': usernameOrEmail,
      'password': password,
    };

    try {
      var response = await http.post(
        url,
        headers: headers,
        body: jsonEncode(body),
      );
      print(response.body);
      if (response.statusCode == 200) {
        print('Sign up request successful');
        print('Response: ${response.body}');
        var jsonResponce = jsonDecode(response.body);
        if (jsonResponce == true) {
          return true;
        } else {
          return false;
        }
      } else {
        print(
            'Failed to make Sign up request. Status code: ${response.statusCode}');
        return false;
      }
    } catch (e) {
      print('Error making Sign up request: $e');
      return false;
    }
  }
}
