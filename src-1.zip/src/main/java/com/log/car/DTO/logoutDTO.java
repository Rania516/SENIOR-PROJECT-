package com.log.car.DTO;

import lombok.Data;

@Data
public class logoutDTO {
    private String usernameOrEmail;
    private String password;

}