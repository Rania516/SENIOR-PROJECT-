package com.log.car.DTO;

import lombok.Data;

@Data
public class customerDTO {

    private String name;
    private String email;
    private String phoneNumebr;
    private String address;
    private String password;

}
