package com.log.car.repo;

import org.springframework.stereotype.Repository;
import com.log.car.models.customer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;



@Repository
public interface customerRepo extends JpaRepository<customer, Long> {

        // Method to add a new customer
        @SuppressWarnings("unchecked")
        customer save(customer customer);

        // Method to delete a customer by id
        void deleteById(Long id);

        // Method to find user
        Optional<customer> findById(Long id);

        // Method to find user email
        customer findByEmail(String  email);

        // Method to fetch all customers
        List<customer> findAll();
}
