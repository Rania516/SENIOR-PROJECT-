package com.log.car.repo;
import org.springframework.stereotype.Repository;
import com.log.car.models.deliveryPerson;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;



@Repository
public interface deliveryRepo extends JpaRepository<deliveryPerson, Long> {

        // Method to add a new customer
        @SuppressWarnings("unchecked")
        deliveryPerson save(deliveryPerson person);

        // Method to delete a customer by id
        void deleteById(Long id);

        // Method to find user
        Optional<deliveryPerson> findById(Long id);

        // Method to find user email
        deliveryPerson findByEmail(String  email);

        // Method to fetch all customers
        List<deliveryPerson> findAll();

        // Method to fetch all available delivery people
        List<deliveryPerson> findByAvailability(boolean availablity);
}
