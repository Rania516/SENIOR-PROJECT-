package com.log.car.services;

import com.log.car.models.customer;
import com.log.car.repo.customerRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;


@Service
public class CustomerService {

    @Autowired
    private final customerRepo customerRepository;


    public CustomerService(customerRepo customerRepository) {
        this.customerRepository = customerRepository;
    }

    public List<customer> getAllcs() {
        return customerRepository.findAll();
    }

    public customer getCustomerById(Long id) {
        return customerRepository.findById(id).orElse(null);
    }

    public  Optional<customer> getCustomerByEmail(String email) {
        return Optional.of(customerRepository.findByEmail(email));
    }

    public customer createCustomer(customer customer) {
        return customerRepository.save(customer);
    }

    public customer updateCustomer(Long id, customer customer) {
        customer existingCustomer = getCustomerById(id);
        if (existingCustomer != null) {
            existingCustomer.setName(customer.getName());
            existingCustomer.setEmail(customer.getEmail());
            existingCustomer.setPhoneNumber(customer.getPhoneNumber());
            existingCustomer.setAdress(customer.getAdress());
            return customerRepository.save(existingCustomer);
        } else {
            return null;
        }
    }

    public void deleteCustomer(Long id) {
        customerRepository.deleteById(id);
    }


}
