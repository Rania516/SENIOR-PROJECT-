package com.log.car.services;

import com.log.car.models.deliveryPerson;
import com.log.car.repo.deliveryRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class DeliveryPersonService  {

    @Autowired
    private final deliveryRepo deliveryPersonRepo;

    public DeliveryPersonService(deliveryRepo deliveryPersonRepo) {
        this.deliveryPersonRepo = deliveryPersonRepo;
    }

    public List<deliveryPerson> getAllcs() {
        return deliveryPersonRepo.findAll();
    }

    public deliveryPerson getDeliveryPersonById(Long id) {
        return deliveryPersonRepo.findById(id).orElse(null);
    }

    public Optional<deliveryPerson> getDeliveryPersonByEmail(String email) {
        return Optional.of(deliveryPersonRepo.findByEmail(email));
    }

    public deliveryPerson createDeliveryPerson(deliveryPerson suggestedUser) {
        return deliveryPersonRepo.save(suggestedUser);
    }

    public deliveryPerson updateDeliveryPerson(Long id, deliveryPerson deliveryPerson) {
        deliveryPerson existingDeliveryPerson = getDeliveryPersonById(id);
        if (existingDeliveryPerson != null) {
            existingDeliveryPerson.setName(deliveryPerson.getName());
            existingDeliveryPerson.setEmail(deliveryPerson.getEmail());
            existingDeliveryPerson.setPhoneNumber(deliveryPerson.getPhoneNumber());
            existingDeliveryPerson.setAdress(deliveryPerson.getAdress());
            return deliveryPersonRepo.save(existingDeliveryPerson);
        } else {
            return null;
        }
    }

    public void deleteDeliveryPerson(Long id) {
        deliveryPersonRepo.deleteById(id);
    }



    public List<deliveryPerson> getAvailablePeople(boolean availablity) {
        List<deliveryPerson> availablePeople = deliveryPersonRepo.findByAvailability(availablity);
        if (availablePeople.size() == 0) {
            System.out.println("No available dilvery person");
            return null;
        }
        System.out.println("List of available dilvery people");
        return availablePeople;

    }
}
