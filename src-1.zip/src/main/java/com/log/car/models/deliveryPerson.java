package com.log.car.models;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "deliveryPerson")
public class deliveryPerson extends user{


    private boolean availability;

    public deliveryPerson() {

    }

    public deliveryPerson(String name, String email, String phoneNumber, String adress, String password,
            boolean availability) {
        super(name, email, phoneNumber, adress, password);
        this.availability = availability;
    }

    public boolean isAvailability() {
        return availability;
    }

    public void setAvailability(boolean availability) {
        this.availability = availability;
    }



}
