package com.log.car.controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;


import com.log.car.DTO.LoginDTO;
import com.log.car.DTO.customerDTO;
import com.log.car.DTO.logoutDTO;

import com.log.car.models.customer;
import com.log.car.services.CustomerService;

import jakarta.servlet.http.HttpSession;



@Scope("session")
@RestController
@RequestMapping("/api/customers")
public class CustomerController {


    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private final CustomerService customerService;



    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    // GET /api/customers
     @PostMapping(
        value = "/logIn",
        consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},
        produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<Boolean> LogIn(@RequestBody LoginDTO userData) {

        try{
        if (userData.getPassword() != "" && userData.getUsernameOrEmail() != "") {

            Optional<customer> userAuth = customerService.getCustomerByEmail(userData.getUsernameOrEmail());
            customer user = userAuth.get();

            if (user.getPassword().equals(userData.getPassword()))
            {
                return ResponseEntity.ok(true);
            }
            else {
                return ResponseEntity.ok(false );
            }

        } else {

            return ResponseEntity.ok(false);
        }
    }catch(Exception e )
    {
        System.err.println("error is : " + e);
        return ResponseEntity.ok(false);
    }
    }

    // POST /api/customers/register
    @PostMapping(
        value = "/register",
        consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},
        produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<Boolean> SignUp(@RequestBody customerDTO userData) {

        customer suggestedUser = new customer(userData.getName(), userData.getEmail(), userData.getPhoneNumebr(), userData.getAddress(), userData.getPassword());
        customer newuser = customerService.createCustomer(suggestedUser);

        if ( newuser != null) {


                System.out.println("email: " + newuser.getEmail());
                System.out.println("password: " + newuser.getPassword());

                    return ResponseEntity.ok(true);


        } else {
            return ResponseEntity.ok(false );
        }
    }

    // POST /api/customers
    @PostMapping(
        value = "/logout",
        consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},
        produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public  ResponseEntity<Boolean> logout(@RequestBody logoutDTO userData, HttpSession session) {
        session.invalidate();
        return ResponseEntity.ok( false);
        // return new String();
    }

    public ResponseEntity<customer> createCustomer(@RequestBody customer customer) {
        customer createdCustomer = customerService.createCustomer(customer);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdCustomer);
    }

    // PUT /api/customers/{id}
    @PutMapping("/{id}")
    public ResponseEntity<customer> updateCustomer(@PathVariable Long id, @RequestBody customer customer) {
        customer updatedCustomer = customerService.updateCustomer(id, customer);
        if (updatedCustomer != null) {
            return ResponseEntity.ok(updatedCustomer);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // DELETE /api/customers/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable Long id) {
        customerService.deleteCustomer(id);
        return ResponseEntity.noContent().build();
    }
}
